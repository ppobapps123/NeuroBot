// GSAP Plugins

export const ScrollSmoother = require("../../../public/assets/gsap-plugins/ScrollSmoother.js");
export const SplitText = require("../../../public/assets/gsap-plugins/SplitText.js");
